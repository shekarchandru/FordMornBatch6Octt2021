import java.util.ArrayList;
import java.util.Iterator;

public class GenericArrayList {

	//ArrayList <Customer> customers = new ArrayList<Customer>();
	ArrayList <Customer> customers ;
	public void populateGenArrayList()
	{
		customers = new ArrayList<Customer>();
		
	Customer c1 = new Customer("C001","Kishore","RTNagar","9922020202",10000,12.34f);
		
		customers.add(c1);
		
		customers.add(new Customer("C002","Kiran Kumar","Vijayanagar","9945620202",12000,12.34f));
		customers.add(new Customer("C003","Madhusudhan","GangaNagar","9922876202",14000,14.34f));
		customers.add(new Customer("C004","Mahesh","Jayanagar","9923450202",15000,15.34f));
		customers.add(new Customer("C005","Rakesh Kumar","Malleswaram","9922567202",16000,16.34f));
		customers.add(new Customer("C006","Ramesh","RTNagar","9934567202",13000,13.34f));
		customers.add(new Customer("C007","Kishore Kumar","RTNagar","9924520202",11000,11.34f));
	}
	public void displayGenArrayList()
	{
		Iterator <Customer> custIter = customers.iterator();
		while(custIter.hasNext())
		{
			//Customer c = (Customer)custIter.next();
			Customer c = custIter.next();
			System.out.println("The Customer "+c);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GenericArrayList gal = new GenericArrayList();
		gal.populateGenArrayList();
		gal.displayGenArrayList();
	}

}
