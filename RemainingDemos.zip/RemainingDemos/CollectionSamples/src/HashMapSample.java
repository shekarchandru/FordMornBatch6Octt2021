import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapSample {

	HashMap myMap = new HashMap();
	HashMap <String,Customer> myMap1 = new HashMap <String,Customer> ();
	
	public void populateHashMap()
	{
		
		
		myMap.put("C1", new Customer("C001","Kishore","RTNagar","9922020202",10000,12.34f));
		myMap.put("C2", new Customer("C002","Kiran Kumar","Vijayanagar","9945620202",12000,12.34f));
		myMap.put("C3", new Customer("C003","Madhusudhan","GangaNagar","9922876202",14000,14.34f));
		myMap.put("C4", new Customer("C004","Mahesh","Jayanagar","9923450202",15000,15.34f));
		myMap.put("C5", new Customer("C005","Rakesh Kumar","Malleswaram","9922567202",16000,16.34f));
		myMap.put("C6",new Customer("C006","Ramesh","RTNagar","9934567202",13000,13.34f));
		myMap.put("C7", new Customer("C007","Kishore Kumar","RTNagar","9924520202",11000,11.34f));
	}
	public void fetchHashMapData()
	{
		Set myKeySet = myMap.keySet();
		Iterator keyIter = myKeySet.iterator();
		while(keyIter.hasNext())
		{
			String myKey = (String)keyIter.next();
			Customer c = (Customer)myMap.get(myKey);
			System.out.println("The Customer for the Key "+myKey+" is "+c);
		}
		
	}
	
	public static void main(String[] args)
	{
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		hms.fetchHashMapData();
	}
}
