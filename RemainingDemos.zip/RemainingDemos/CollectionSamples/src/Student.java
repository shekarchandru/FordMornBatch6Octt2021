
public class Student implements Comparable <Student>{

	String studentId;
	String studentName;
	int score;
	
	
	public Student() {
		super();
	}


	public Student(String studentId, String studentName, int score) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.score = score;
	}

	

	public String getStudentId() {
		return studentId;
	}


	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}


	public String getStudentName() {
		return studentName;
	}


	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}


	public int getScore() {
		return score;
	}


	public void setScore(int score) {
		this.score = score;
	}


	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", score=" + score + "]";
	}

// Bmar   Aabu
/*	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if(this.studentId.compareTo(o.studentId) > 0)
		{
			return 1;
		}
		else if(this.studentId.compareTo(o.studentId) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/
	
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if(this.studentName.compareTo(o.studentName) > 0)
		{
			return 1;
		}
		else if(this.studentName.compareTo(o.studentName) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
/*	@Override
	public int compareTo(Student o)
	{
		if(this.score > o.score)
		{
			return 1;
		}
		else if(this.score < o.score)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/
}
