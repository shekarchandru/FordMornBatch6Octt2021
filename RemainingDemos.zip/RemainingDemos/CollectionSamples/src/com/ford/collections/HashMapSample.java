package com.ford.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class HashMapSample {

	HashMap <String,Employee> hashMap;
	public HashMapSample()
	{
		hashMap = new HashMap <String,Employee> ();
	}
	public void populateHashMap()
	{
		hashMap.put("E004", new Employee("E004","Harsha","RTNagar","9844965994",2000.0f,12.34f));
		hashMap.put("E003", new Employee("E003","Teena","Vijayanagar","9843294994",3000.0f,13.34f));
		hashMap.put("E005", new Employee("E005","Mahesh","Jayanagar","9844344994",5000.0f,11.34f));
		hashMap.put("E001", new Employee("E001","Keerthana","Malleswaram","9867994994",1000.0f,10.34f));
		hashMap.put("E002", new Employee("E002","Rakesh","KRPuram","9844994678",4000.0f,12.34f));
		hashMap.put("E006", new Employee("E006","Rajesh","KRNagar","9844978994",3000.0f,12.34f));
	}
	public void fetchHashMapData()
	{
		Set myKeys = hashMap.keySet();
		Iterator <String> keyIter = myKeys.iterator();
		while(keyIter.hasNext())
		{
			String myKey = keyIter.next();
			System.out.println("The Value for the Key : "+myKey+ " is :"+hashMap.get(myKey));
		}
	}
	public void fetchHashMapDataThruEntrySet()
	{
		Set <Entry<String,Employee>> myEntrySet = hashMap.entrySet();
		
		Iterator <Entry<String,Employee>> entrySetIter = myEntrySet.iterator();
		
		while(entrySetIter.hasNext())
		{
			Entry <String,Employee> myEntry = entrySetIter.next();
			String myKey = myEntry.getKey();
			Employee employee = myEntry.getValue();
			System.out.println("The Key is "+myKey+" And Corresponding Value is :"+employee);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		hms.fetchHashMapData();
		System.out.println("--------------------");
		hms.fetchHashMapDataThruEntrySet();

	}

}
