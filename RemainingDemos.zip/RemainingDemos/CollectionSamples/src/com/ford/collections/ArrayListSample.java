package com.ford.collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {
	
	ArrayList employees;
	public void populateArrayList()
	{
		employees = new ArrayList();
		Employee e1 = new Employee("E001","Harsha","RTNagar","9838388383",1000.0f,12.3f);
		employees.add(e1);
		employees.add(new Employee("E002","Rakesh Kumar","RTNagar","9838458383",1000.0f,12.3f));
		employees.add(new Employee("E003","Rajesh","Koramangala","9867388383",4000.0f,13.3f));
		employees.add(new Employee("E004","Suman","Malleswaram","9838388783",3000.0f,13.3f));
		employees.add(new Employee("E005","Keerthana","Jayanagar","9845388383",7000.0f,14.3f));
		employees.add(new Employee("E006","Mahesh","Vijayanagar","9838388783",6000.0f,13.3f));
		employees.add(new Employee("E007","Anuj","RSPuram","9838356383",3000.0f,12.3f));
		
	}
	public void fetchArrayListElements()
	{
		Iterator empIter = employees.iterator();
		while(empIter.hasNext())
		{
			Employee e = (Employee) empIter.next();
			System.out.println(e);
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListSample als = new ArrayListSample();
		als.populateArrayList();
		als.fetchArrayListElements();

	}

}
