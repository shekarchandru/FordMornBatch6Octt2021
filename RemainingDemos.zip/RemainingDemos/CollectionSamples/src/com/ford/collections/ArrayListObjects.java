package com.ford.collections;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListObjects {
	
	ArrayList myList;
	public void populateArrayList()
	{
		myList = new ArrayList();
		myList.add(new Employee("E001","Harsha","RTNagar","9838388383",1000.0f,12.3f));
		myList.add(20000);
		myList.add(true);
		myList.add(234556.67d);
		myList.add(12.34f);
	}
	public void fetchArrayList()
	{
		Iterator myListIter = myList.iterator();
		while(myListIter.hasNext())
		{
			Object obj = myListIter.next();
			System.out.println(obj);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListObjects alo = new ArrayListObjects();
		alo.populateArrayList();
		alo.fetchArrayList();
		

	}

}
