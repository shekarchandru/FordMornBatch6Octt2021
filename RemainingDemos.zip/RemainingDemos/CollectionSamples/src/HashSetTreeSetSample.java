import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

public class HashSetTreeSetSample {

	HashSet hs = new HashSet();
	TreeSet ts = new TreeSet();
	public void populateHashSet()
	{
		
		hs.add("Yasmeen");
		hs.add("Faheem");
		hs.add("Emanuel");
		hs.add("Ganesh");
		hs.add("Amarendra");
		hs.add("Brajesh");
		hs.add("Harish");
		hs.add("Zeenat");
		hs.add("Mohan");
		hs.add("Mohan");
		
		
	}
	public void fetchHashSet()
	{
		Iterator hsIter  = hs.iterator();
		while(hsIter.hasNext())
		{
			String str = (String)hsIter.next();
			System.out.println("Element in Hash Set "+str);
		}
		
		
	}
	public void populateTreeSet()
	{
		ts.add("Yasmeen");
		ts.add("Faheem");
		ts.add("Emanuel");
		ts.add("Ganesh");
		ts.add("Amarendra");
		ts.add("Brajesh");
		ts.add("Harish");
		ts.add("Zeenat");
		ts.add("Mohan");
		ts.add("Mohan");
	}
	public void fetchTreeSet()
	{
		Iterator tsIter  = ts.iterator();
		while(tsIter.hasNext())
		{
			String str = (String)tsIter.next();
			System.out.println("Element in Tree Set "+str);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSetTreeSetSample hsts = new HashSetTreeSetSample();
		System.out.println("--------------HASHSET-------------");
		hsts.populateHashSet();
		hsts.fetchHashSet();
		System.out.println("--------------TREESET-------------");
		hsts.populateTreeSet();
		hsts.fetchTreeSet();
	}

}
