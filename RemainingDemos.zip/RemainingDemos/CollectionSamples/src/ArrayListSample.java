import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListSample {

	ArrayList myList;
	ArrayList myList1 = new ArrayList();
	public void populateArrayList()
	{
		myList = new ArrayList();
		myList.add("Karnataka");
		myList.add(10000);
		myList.add(2345.56);
		myList.add(23456677.78);
		myList.add(true);
	}
	public void fetchArrayListElements()
	{
		Iterator aListIter = myList.iterator();
		while(aListIter.hasNext())
		{
		//	int i = aListIter.next();
			System.out.println("The Element is "+aListIter.next());
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayListSample als = new ArrayListSample();
		als.populateArrayList();
		als.fetchArrayListElements();
	}

}
