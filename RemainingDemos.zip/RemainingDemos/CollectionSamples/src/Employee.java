import java.util.Comparator;

public class Employee {
	
	String empId;
	String empName;
	String empCity;
	int empSalary;
	
	
	
	public Employee() {
		super();
	}



	public Employee(String empId, String empName, String empCity, int empSalary) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empCity = empCity;
		this.empSalary = empSalary;
	}



	public String getEmpId() {
		return empId;
	}



	public void setEmpId(String empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public String getEmpCity() {
		return empCity;
	}



	public void setEmpCity(String empCity) {
		this.empCity = empCity;
	}



	public int getEmpSalary() {
		return empSalary;
	}



	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empCity=" + empCity + ", empSalary=" + empSalary
				+ "]";
	}
	
}

class IdSorter implements Comparator <Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if(o1.empId.compareTo(o2.empId) > 0)
		{
			return 1;
		}
		else if(o1.empId.compareTo(o2.empId) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
}
class CitySorter implements Comparator <Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if(o1.empCity.compareTo(o2.empCity) > 0)
		{
			return 1;
		}
		else if(o1.empCity.compareTo(o2.empCity) < 0)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	
}
class SalarySorter implements Comparator <Employee>
{

	@Override
	public int compare(Employee o1, Employee o2) {
		// TODO Auto-generated method stub
		if(o1.empSalary > o2.empSalary)
		{
			return -1;
		}
		else if(o1.empSalary < o2.empSalary)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
}



