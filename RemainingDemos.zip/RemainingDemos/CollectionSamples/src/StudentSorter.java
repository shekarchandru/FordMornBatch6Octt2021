import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class StudentSorter {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Student s1 = new Student("S004","Madhusudhan",75);
		Student s2 = new Student("S006","Akash",85);
		Student s3 = new Student("S001","Emanuel",95);
		Student s4 = new Student("S003","Yasmeen",65);
		Student s5 = new Student("S005","Zeenat",73);
		Student s6 = new Student("S002","David",92);
		
		ArrayList <Student> students = new ArrayList<Student>();
		students.add(s1);
		students.add(s2);
		students.add(s3);
		students.add(s4);
		students.add(s5);
		students.add(s6);
		System.out.println("----------w.o Sorting-----------");
		Iterator <Student> studIter1 = students.iterator();
		while(studIter1.hasNext())
		{
			Student s = (Student)studIter1.next();
			System.out.println(s);
		}
		//students.sort(null);
		Collections.sort(students);
		System.out.println("----------Sorted on StudentSCore-----------");
		Iterator <Student> studIter = students.iterator();
		while(studIter.hasNext())
		{
			Student s = (Student)studIter.next();
			System.out.println(s);
		}
		

	}

}
