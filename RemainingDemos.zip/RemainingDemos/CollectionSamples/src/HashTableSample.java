import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;

public class HashTableSample {

	Hashtable myhTable = new Hashtable();
	public void populateHashTable()
	{
		myhTable.put("E001", 10000);
		myhTable.put("E002", 11000);
		myhTable.put("E003", 12000);
		myhTable.put("E004", 13000);
		myhTable.put("E005", 14000);
		myhTable.put("E006", 15000);
		myhTable.put("E007", 16000);
		myhTable.put("E008", 17000);
		myhTable.put("E008", 19000);
	}
	public void fetchHashTable()
	{
		Enumeration myKeys = myhTable.keys();
		while(myKeys.hasMoreElements())// iter.hasNext()
		{
			String key = (String)myKeys.nextElement();// iter.next()
					System.out.println("The Value for the Key "+key+" is :"+myhTable.get(key));
		}
	}
	public void useFunctions()
	{
		Collection c = myhTable.values();
		Iterator cIter = c.iterator();
		while(cIter.hasNext())
		{
			Integer itr = (Integer)cIter.next();
			System.out.println("The Value is "+itr);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashTableSample hts = new HashTableSample();
		hts.populateHashTable();
		hts.fetchHashTable();
		System.out.println("-------------------");
		hts.useFunctions();
	}

}
