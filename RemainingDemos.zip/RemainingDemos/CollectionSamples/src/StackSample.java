import java.util.Iterator;
import java.util.Stack;

public class StackSample {
	
	Stack <String> myStack;
	Stack <Customer> customers = new Stack<Customer>();
	public void populateStack()
	{
		myStack = new Stack<String>();
		myStack.push("Bangalore");
		myStack.push("Mangalore");
		myStack.push("Hyderabad");
		myStack.push("Chennai");
		myStack.push("Coimbatore");
		myStack.push("Vijayawada");
		myStack.push("Mumbai");
		myStack.push("Kolkata");
		myStack.push("Trivandrum");
		myStack.push("Ernakulam");
		myStack.push("Belgaum");
		
	}
	public void displayStackElements()
	{
		System.out.println("Capacity of the stack is "+myStack.capacity());
		System.out.println("Size of the stack is "+myStack.size());
		while(myStack.isEmpty()==false)
		{
			String city = myStack.pop();
			System.out.println("The City Popped is "+city);
		}
		System.out.println("Capacity of the stack is "+myStack.capacity());
		System.out.println("Size of the stack is "+myStack.size());
	}
	public void displayStackThruIterator()
	{
		Iterator stackIter = myStack.iterator();
		while(stackIter.hasNext())
		{
			String city = (String)stackIter.next();
			System.out.println("The City is "+city);
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StackSample ss = new StackSample();
	/*	ss.populateStack();
		ss.displayStackElements();
		ss.populateStack();
		ss.displayStackThruIterator(); */
		ss.populateStack();
		ss.displayStackThruIterator(); 
		ss.displayStackElements();

	}

}
