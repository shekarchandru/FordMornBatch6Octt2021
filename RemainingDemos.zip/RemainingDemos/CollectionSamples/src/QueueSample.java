import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueSample {

	Queue <Customer> myQueue;
	Queue <String> myQueueStr;
	public void populateCustomerQueue()
	{
		/*
		 * 	Customer c1 = new Customer("C001","Kishore","RTNagar","9922020202",10000,12.34f);
		
		customers.add(c1);
		customers.add(new Customer("C007","Kishore Kumar","RTNagar","9924520202",11000,11.34f));
		customers.add(new Customer("C002","Kiran Kumar","Vijayanagar","9945620202",12000,12.34f));
		customers.add(new Customer("C003","Madhusudhan","GangaNagar","9922876202",14000,14.34f));
		customers.add(new Customer("C004","Mahesh","Jayanagar","9923450202",15000,15.34f));
		customers.add(new Customer("C005","Rakesh Kumar","Malleswaram","9922567202",16000,16.34f));
		customers.add(new Customer("C006","Ramesh","RTNagar","9934567202",13000,13.34f));
		 */
		myQueue = new PriorityQueue<Customer>();
		Customer c1 = new Customer("C001","Kishore","RTNagar","9922020202",10000,12.34f);
		myQueue.add(c1);
		myQueue.add(new Customer("C002","Kiran Kumar","Vijayanagar","9945620202",12000,12.34f));
		myQueue.add(new Customer("C003","Madhusudhan","GangaNagar","9922876202",14000,14.34f));
		myQueue.add(new Customer("C004","Mahesh","Jayanagar","9923450202",15000,15.34f));
		myQueue.add(new Customer("C005","Rakesh Kumar","Malleswaram","9922567202",16000,16.34f));
		myQueue.add(new Customer("C006","Ramesh","RTNagar","9934567202",13000,13.34f));
		myQueue.add(new Customer("C007","Kishore Kumar","RTNagar","9924520202",11000,11.34f));
		
	}
	public void fetchCustomerQueueElements()
	{
		while(myQueue.isEmpty() == false)
		{
			Customer cust = myQueue.remove();
			System.out.println("The Customer Removed from Queue is "+cust);
		}
	}
	public void fetchCustomerQueueThruIter()
	{
		Iterator custIter = myQueue.iterator();
		while(custIter.hasNext())
		{
			Customer customer = (Customer)custIter.next();
			System.out.println("Customer "+customer);
		}
	}
	public void populateStringQueue()
	{
		myQueueStr = new PriorityQueue<String>();
		myQueueStr.add("Bangalore");
		myQueueStr.add("Mangalore");
		myQueueStr.add("Hyderabad");
		myQueueStr.add("Chennai");
		myQueueStr.add("Coimbatore");
		myQueueStr.add("Vijayawada");
		myQueueStr.add("Mumbai");
		myQueueStr.add("Kolkata");
		myQueueStr.add("Trivandrum");
		myQueueStr.add("Ernakulam");
		myQueueStr.add("Belgaum");
	}
	public void fetchStringQueueElements()
	{
		while(myQueueStr.isEmpty() == false)
		{
			String city = myQueueStr.remove();
			System.out.println("The City Removed from Queue is "+city);
		}
	}
	public void fetchStringQueueIter()
	{
		Iterator qIter = myQueueStr.iterator();
		while(qIter.hasNext())
		{
			String strCity =  (String)qIter.next();
			System.out.println("City is "+strCity);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		QueueSample qs = new QueueSample();
	/*	qs.populateStringQueue();
		qs.fetchStringQueueElements();
		qs.populateStringQueue();
		qs.fetchStringQueueIter();*/
		
		qs.populateCustomerQueue();
		qs.fetchCustomerQueueElements();
		qs.populateCustomerQueue();
		qs.fetchCustomerQueueThruIter();

	}

}
