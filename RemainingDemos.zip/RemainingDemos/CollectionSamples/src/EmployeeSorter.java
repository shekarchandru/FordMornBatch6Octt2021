import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class EmployeeSorter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee e1 = new Employee("E005","Harsha","Faridabad",25000);
		Employee e2 = new Employee("E008","Adarsh","Ahmedabad",35000);
		Employee e3 = new Employee("E002","Chandu","Chandigarh",75000);
		Employee e4 = new Employee("E004","Kiran","Zaffarpur",45000);
		Employee e5 = new Employee("E003","Zeenat","Ernakulam",85000);
		Employee e6 = new Employee("E006","David","Cochin",75000);
		Employee e7 = new Employee("E007","Yasmeen","Bhopal",50000);
		Employee e8 = new Employee("E001","Faheem","Bangalore",40000);
		
		ArrayList <Employee> employees = new ArrayList<Employee>();
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		employees.add(e5);
		employees.add(e6);
		employees.add(e7);
		employees.add(e8);
		System.out.println("---------------------Un Sorted------------------------");
		
		Iterator <Employee> empIter = employees.iterator();
		while(empIter.hasNext())
		{
			Employee e = (Employee)empIter.next();
			System.out.println(e);
		}
		System.out.println("---------------------ID Sorted------------------------");
		
		Collections.sort(employees, new IdSorter());
		Iterator <Employee> empIdIter = employees.iterator();
		while(empIdIter.hasNext())
		{
			Employee e = (Employee)empIdIter.next();
			System.out.println(e);
		}
		System.out.println("---------------------CITY Sorted------------------------");
		
		Collections.sort(employees, new CitySorter());
		Iterator <Employee> empCityIter = employees.iterator();
		while(empCityIter.hasNext())
		{
			Employee e = (Employee)empCityIter.next();
			System.out.println(e);
		}
		System.out.println("---------------------SALARY Sorted------------------------");
		
		Collections.sort(employees, new SalarySorter());
		Iterator <Employee> empSalIter = employees.iterator();
		while(empSalIter.hasNext())
		{
			Employee e = (Employee)empSalIter.next();
			System.out.println(e);
		}
		
	}

}
