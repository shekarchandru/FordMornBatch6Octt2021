package com.ford.customexception;

public class Recruitment {
	
	public void scrutinizeAge(int age)
	{
		System.out.println("Age Scrutinization being carried out...");
		try 
		{
			checkAge(age);
		} catch (InvalidAgeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println(e.message);
		}
		finally
		{
			System.out.println("We reach this point irrespective of the exception...");
			System.out.println("Closure of resources,cleaning up of resources can be done here");
		}
		System.out.println("We finished Age scrutinization...");
		
	}

	public void checkAge(int age) throws InvalidAgeException,ArithmeticException
	{
		
		if((age < 20) || (age >= 30))
		{
			throw new InvalidAgeException("Sorry!!! Valid Age is 20-30 age is "+age);
		}
		else
		{
			System.out.println("Valid Age.... age is "+age);
			System.out.println("Further Recruitment process Proceeds....");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Recruitment Process started....");
		Recruitment recruit = new Recruitment();
		/*
			recruit.checkAge(23);
			recruit.checkAge(24);
			recruit.checkAge(33);
			recruit.checkAge(21);
			recruit.checkAge(26);
		}
		catch(InvalidAgeException iae)
		{
			iae.printStackTrace();
			System.out.println(iae.message);
		}*/
		
		recruit.scrutinizeAge(23);
		recruit.scrutinizeAge(24);
		recruit.scrutinizeAge(33);
		recruit.scrutinizeAge(21);
		recruit.scrutinizeAge(26);
		System.out.println("Recruitment Process Completed....");
		
		

	}

}
