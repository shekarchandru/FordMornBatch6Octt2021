package com.ford.files;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BinaryStreamReader {

	File filePath;
	FileInputStream fis;
	byte[] myBytes = new byte[100];
	public void  readFromBinaryStream()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\customer.txt");
		try {
			fis =  new FileInputStream(filePath);
			fis.read(myBytes);
			String strBytes = new String(myBytes);
			System.out.println("The String Read is "+strBytes);
			fis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinaryStreamReader bsr = new BinaryStreamReader();
		bsr.readFromBinaryStream();

	}

}
