package com.ford.files;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CharStreamWriter {

	File filePath;
	FileWriter fw;
	String str = "We are writing to Character Stream...";
	public void writeToCharStream()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\supplier.txt");
		try 
		{
			fw = new FileWriter(filePath);
			fw.write(str);
			System.out.println("Written into Char Stream successfully...");
			fw.flush();
			fw.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CharStreamWriter csw = new CharStreamWriter();
		csw.writeToCharStream();

	}

}
