package com.ford.files;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataInputOutputStreamReaderWriter {

	File filePath;
	DataOutputStream dos;
	DataInputStream dis;
	
	public void readWriteDataStream()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\supplier.txt");
		try {
			dos = new DataOutputStream(new FileOutputStream(filePath));
			dos.writeUTF("This is a String");
			dos.writeBoolean(true);
			dos.writeFloat(12234.34f);
			dos.writeDouble(2344555.45);
			dos.writeInt(40000);
			
			dos.flush();
			dos.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
		try {
			dis = new DataInputStream(new FileInputStream(filePath));
			System.out.println("String Data Read "+dis.readUTF());
			System.out.println("Boolean Data Read "+dis.readBoolean());
			System.out.println("Float  Data Read "+dis.readFloat());
			System.out.println("DOuble  Data Read "+dis.readDouble());
			System.out.println("Int   Data Read "+dis.readInt());
			dis.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DataInputOutputStreamReaderWriter dios = new DataInputOutputStreamReaderWriter();
		dios.readWriteDataStream();
	}

}
