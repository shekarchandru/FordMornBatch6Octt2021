package com.ford.files;

import java.io.BufferedWriter;
import java.io.File;

public class BufferedCharStreamWriter {

	BufferedWriter bw;
	File filePath;
	public void writeToCharStreamThroughBuffer()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\customer.txt");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
