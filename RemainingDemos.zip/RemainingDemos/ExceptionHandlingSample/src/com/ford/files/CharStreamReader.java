package com.ford.files;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CharStreamReader {

	FileReader fr;
	File filePath;
	public void readFromCharStream()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\supplier.txt");
		try 
		{
			fr = new FileReader(filePath);
			int chars;
			while((chars = fr.read()) != -1)
			{
				System.out.print((char)chars);
			}
			fr.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CharStreamReader csr = new CharStreamReader();
		csr.readFromCharStream();

	}

}
