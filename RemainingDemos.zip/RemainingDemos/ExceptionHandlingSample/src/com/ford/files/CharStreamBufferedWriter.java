package com.ford.files;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class CharStreamBufferedWriter {

	BufferedWriter bWriter;
	File filePath;
	
	public void writeToCharStreamThruBuffer()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\student1.txt");
		try {
		//	bWriter = new BufferedWriter(new FileWriter(filePath),10000);
			bWriter = new BufferedWriter(new FileWriter(filePath));
			bWriter.write("We are writing through Buffer into Char Stream...");
			bWriter.flush();
			bWriter.close();
			System.out.println("We have written into char stream , through buffer successfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CharStreamBufferedWriter csbw = new CharStreamBufferedWriter();
		csbw.writeToCharStreamThruBuffer();

	}

}
