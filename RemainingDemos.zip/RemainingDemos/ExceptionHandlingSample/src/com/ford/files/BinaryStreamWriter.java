package com.ford.files;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BinaryStreamWriter {

	FileOutputStream fos;
	File filePath;
	byte myBytes[] = new byte[100];
	String str = new String("We are writing into Binary Stream");
	public void writeToBinaryStream()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\customer.txt");
		try 
		{
			fos = new FileOutputStream(filePath);
			myBytes = str.getBytes();
			fos.write(myBytes);
			System.out.println("Successfuly written into Binary Stream");
			fos.flush();
			fos.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinaryStreamWriter bsw = new BinaryStreamWriter();
		bsw.writeToBinaryStream();

	}

}
