package com.ford.files;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.IOException;

public class BufferedStreamWriter {

	File filePath;
	BufferedOutputStream bos;
	BufferedInputStream bis;
	byte[] myBytes = new byte[100];
	String str = "We are writing this to Console..";
	public void witeToConsole()
	{
		// filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\customer.txt");
		bos = new BufferedOutputStream(System.out);
		myBytes = str.getBytes();
		try {
			bos.write(myBytes);
			System.out.println("We wrote to Console...");
			bos.flush();
			bos.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public void readFromKeyBoard()
	{
		bis = new BufferedInputStream(System.in);
		System.out.println("Enter a String to read thru buffer....");
		try {
			bis.read(myBytes);
			String str = new String(myBytes);
			System.out.println("The Data Read is "+str);
			bis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamWriter bsw = new BufferedStreamWriter();
		//bsw.witeToConsole();
		bsw.readFromKeyBoard();

	}

}
