package com.ford.files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CharStreamBufferedReader {

	BufferedReader bReader;
	File filePath;
	public void readFromCharStreamThruBuffer()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\student1.txt");
		try {
			bReader = new BufferedReader(new FileReader(filePath));
			String readStr = bReader.readLine();
			System.out.println("The String that was read :"+readStr);
			bReader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CharStreamBufferedReader csbr = new CharStreamBufferedReader();
		csbr.readFromCharStreamThruBuffer();

	}

}
