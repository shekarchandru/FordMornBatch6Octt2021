package com.ford.files;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationSample {

	ObjectOutputStream ops;
	File filePath;
	public void serializeEmployeeObject()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\employees.txt");
		try {
			ops = new ObjectOutputStream(new FileOutputStream(filePath));
			Employee emp1 = new Employee("E001","Harsha","RTNagar","9883993993",1000.0f,12.34f);
			ops.writeObject(emp1);
			ops.flush();
			ops.close();
			System.out.println("We have serialized Object into stream...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SerializationSample serialization = new SerializationSample();
		serialization.serializeEmployeeObject();
	}

}
