package com.ford.files;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedStreamFileWriter {

	BufferedOutputStream bos;
	File filePath;
	byte[] myBytes = new byte[100];
	String str ="We ae writing to files using Buffer...";
	public void writeToBufferedFile()
	{
		filePath = new File("C:\\Training2020-21-22\\FordIndia2021-22Sept06\\DayWiseSessions\\Pega-AEM-ReactBatchFrm6Oct2021\\MyFiles\\student.txt");
		try {
		//	bos = new BufferedOutputStream(new FileOutputStream(filePath),10000);//we can specify buffer size
			bos = new BufferedOutputStream(new FileOutputStream(filePath));
			myBytes = str.getBytes();
			bos.write(myBytes);
			System.out.println("we wrote to file through buffer");
			bos.flush();
			bos.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamFileWriter bsfw = new BufferedStreamFileWriter();
		bsfw.writeToBufferedFile();

	}

}
