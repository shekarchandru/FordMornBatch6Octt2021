package com.ford.exception;

public class ArrayExceptionSample {

	public void manipulateArray()
	{
		int arr[] = new int[10];
		System.out.println("We are about to populate an Array");
		for(int i=0;i<10;i++)
		{
			arr[i] = (i+1)*10;
		}
		System.out.println("We are about to Fetch array elements ...");
		try
		{
			for(int j=0;j<=10;j++)
			{
				System.out.println("Element is "+arr[j]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			//throw aie;
			aie.printStackTrace();
		}
		System.out.println("We Finished Array Manipulation...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are doing array Manipulation....");
		ArrayExceptionSample aes = new ArrayExceptionSample();
		aes.manipulateArray();
		System.out.println("We Finished Array Manipulation....");
	}

}
