package com.ford.exception;

public class ExceptionSample {

	public void calculate(int numerator,int denominator)
	{
		int result = 0;
		System.out.println("We are about to Perform Calculation...");
		try
		{
			result = numerator/ denominator ;
		}
		catch(ArithmeticException ae)
		{
			//System.out.println(ae.getMessage());
			ae.printStackTrace();
		}
		System.out.println("The Result is : "+result);
		System.out.println("We finished Calculation...");
		System.out.println("we are about to leave function....");
		System.out.println("Leaving Calculator functions...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are about to invoke Calculator Function...");
		ExceptionSample eSample = new ExceptionSample();
	/*	try
		{*/
			eSample.calculate(100, 50);
			eSample.calculate(100, 25);
			eSample.calculate(100, 0);
			eSample.calculate(200, 50);
			eSample.calculate(200, 40);
	/*	}
		catch(ArithmeticException ae)
		{
			System.out.println(ae.getMessage());
		}*/
		System.out.println("We have finished calls....");

	}

}
