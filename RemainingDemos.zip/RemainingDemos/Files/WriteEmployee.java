import java.io.*;
public class WriteEmployee
{
public static void main(String args[])
{
Employee e=new Employee(1001,"Billy Zoe",4000.50);
try
{
FileOutputStream fos=new FileOutputStream("employee.txt");
ObjectOutputStream oos=new ObjectOutputStream(fos);
oos.writeObject(e);
//oos.writeObject(e);
oos.flush();
oos.close();
}
catch(IOException ioe)
{
System.out.println("Exception :"+ioe.toString());
}
}
}