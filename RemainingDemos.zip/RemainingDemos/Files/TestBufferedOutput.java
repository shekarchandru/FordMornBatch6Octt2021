import java.io.*;
public class TestBufferedOutput
{
public static void main(String args[])
{
String str=("creating a Program using BufferedOutPutStream Class");
byte buffer[]=str.getBytes();
BufferedOutputStream br=new BufferedOutputStream(System.out);
try
{
br.write(buffer,0,50);
br.flush();
}
catch(IOException ioe)
{
System.out.println("Exception :"+ioe.toString());
}
}
}