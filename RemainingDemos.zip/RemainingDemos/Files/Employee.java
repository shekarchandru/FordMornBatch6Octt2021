import java.io.*;
public class Employee implements Serializable
{
private int empcode;
private String empname;
private double empsal;
public Employee()
{
}
public Employee(int code,String name,double sal)
{
empcode=code;
empname=name;
empsal=sal;
}
public void show()
{
System.out.println("Emp Code :"+empcode);
System.out.println("Emp Name :"+empname);
System.out.println("Emp Salary :"+empsal);
}
}
