import java.io.*;
public class TestFileInput
{
public static void main(String args[])
{
byte buffer[]=new byte[100];
try
{
FileInputStream file=new FileInputStream("filein.txt");
file.read(buffer,0,50);
}
catch(Exception e)
{
System.out.println("Excfeption :"+e.toString());
}
String str=new String(buffer);
System.out.println(str);
}
}