import java.io.*;
public class TestFileOutput
{
public static void main(String args[])
{
byte buffer[]=new byte[100];
try
{
System.in.read(buffer,0,100);
}
catch(IOException ioe)
{
System.out.println("Exception :"+ioe.toString());
}
try
{
FileOutputStream fout=new FileOutputStream("filein.txt");
fout.write(buffer);
}
catch(FileNotFoundException fnfe)
{
System.out.println("Exception :"+fnfe.toString());
}
catch(IOException ioe)
{
System.out.println("Exception :"+ioe.toString());
}
}
}
