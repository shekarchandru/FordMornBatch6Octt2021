import java.io.*;
public class TestBuffer
{
	public static void main(String arg[])
	{
	System.out.println("Please Enter a String :");
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	//BufferedReader class;
	String str=new String();
	try
	{
	str=br.readLine();
	}
	catch(IOException ioe)
	{
	System.out.println("The string entered is :");
	}
	System.out.println(str);
	}
}