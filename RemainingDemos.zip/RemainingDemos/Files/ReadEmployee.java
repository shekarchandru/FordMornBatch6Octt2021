import java.io.*;
class Employee implements Serializable
{
private int empcode;
private String empname;
private double empsal;
	public Employee()
	{
	}
	public Employee(int code,String name,double sal)
	{
	empcode=code;
	empname=name;
	empsal=sal;
	}
	public void show()
	{
	System.out.println("Emp Code :"+empcode);
	System.out.println("Emp Name :"+empname);
	System.out.println("Emp Salary :"+empsal);
	}
}
public class ReadEmployee
{
	public static void main(String arg[])
	{
	Employee e=new Employee();
	try
	{
	FileInputStream fis=new FileInputStream("employee.txt");
	ObjectInputStream ois=new ObjectInputStream(fis);
	e=(Employee)ois.readObject();
	e.show();
	}
	catch(IOException ioe)
	{
	System.out.println("Exception :"+ioe.toString());
	}
	catch(ClassNotFoundException cnfe)
	{
	System.out.println("Exception :"+cnfe.toString());
	}
	}
}


