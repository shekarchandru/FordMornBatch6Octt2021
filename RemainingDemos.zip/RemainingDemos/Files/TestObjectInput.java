import java.io.*;
import java.util.Date;
public class TestObjectInput
{
public static void main(String args[]) throws IOException,ClassNotFoundException
{
FileInputStream fin=new FileInputStream("myfile.txt");
ObjectInputStream ois=new ObjectInputStream(fin);
String str=(String)ois.readObject();
Date date=(Date)ois.readObject();
System.out.println(str+date);
}
}