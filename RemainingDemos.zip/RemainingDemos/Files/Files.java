import java.io.*;
import java.lang.*;
class Files
{
public static void main(String args[]) throws NullPointerException
{
String dirName="C:/Test";
/*Creates an instance of the work.txt file using thr File class.*/
File f=new File(dirName,"work.txt");
/*Creates an instance of the renFile.txt file using the File class.*/
File f3=new File(dirName,"renFile.txt");
/*Displays the name of  the file using the getName() method. */
System.out.println("File name is :"+f.getName());
/*Displays the path of the file using the getPath() method */
System.out.println("Path of the File is :"+f.getPath());
/*Displays the parent Directory of the file using the getParent() method*/
System.out.println("Parent Directory is :"+f.getParent());
/*Displays the contents of the Test Directory using the List() method.*/
System.out.println("Listing the contents of the Test Directory  :");
/*Creates an instance of the Test Directory using the File class */
File f1=new File(dirName);

String str;
str="WELCOME TO FILES";
//f3.Write(str);
//String s[]=new String();
//String s=f1.list();


/*for(int i=0;i<20;i++)
{
	s[i]=new String();
}*/

//s=f1.list();

String s[]=f1.list();



/*The loop executes for the number of files and directories present in the test Directory.*/
/*for(int i=0;i<s.length;i++)
{


/*Creates an instance of the File class for the file or directory contained in the Test Directory */
//
//File f2=new File("\t"+dirName+"/"+s[i]);
/*If the contents of the Test Directory is a directory then enters the if block of the loop otherwise enters the else block*/
/*if(f2.isDirectory())
{
System.out.println("\t"+s[i]+"is a directory");
}
else
{
System.out.println("\t"+s[i]+"is a file");
}

}*/
}
}
