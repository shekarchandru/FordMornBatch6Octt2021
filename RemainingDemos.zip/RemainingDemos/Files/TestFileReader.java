import java.io.*;
public class TestFileReader
{
public static void main(String arg[])
{
try
{
File file=new File("stream.txt");
FileReader f=new FileReader(file);
int ch;
while((ch=f.read())!=-1)
{
System.out.print((char)ch);
}
}
catch(FileNotFoundException fnfe)
{
System.out.println("Exception :"+fnfe.toString());
}
catch(IOException ioe)
{
System.out.println("Exception :"+ioe.toString());
}
}
}
