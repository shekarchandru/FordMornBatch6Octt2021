package com.ford.relationships;

public abstract class Shapes {
	
	//public abstract void draw();
	
	public void drawLocal()
	{
		System.out.println("Drawing something locally...");
	}

}
