package com.ford.relationships;

public final class MyFinal {

	public final void finalMethod()
	{
		System.out.println("This is nt to be overridden...");
	}
	
	public void nonFinalMethod()
	{
		System.out.println("This automatically becomes final....");
	}
	
}
