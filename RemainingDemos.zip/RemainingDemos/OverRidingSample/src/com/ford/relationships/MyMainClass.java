package com.ford.relationships;

public class MyMainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		MyFinal myFinal = new MyFinal();
		myFinal.finalMethod();
		myFinal.nonFinalMethod();
	}

}
