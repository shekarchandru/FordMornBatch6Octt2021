package com.ford.relationships;

public class DerivedClass extends BaseClass{

	@Override
	public void display()
	{
		System.out.println("Displaying Derived Class...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BaseClass bc = new BaseClass(); //OK
		DerivedClass  dc = new DerivedClass(); //OK
		bc.display();
		dc.display();
		
		bc = new DerivedClass(); //OK
		//dc = new BaseClass();//NOT OK
		
		dc = (DerivedClass)new BaseClass();//COMPILER WISE OK- BUT RUNTIME:

	}

}
