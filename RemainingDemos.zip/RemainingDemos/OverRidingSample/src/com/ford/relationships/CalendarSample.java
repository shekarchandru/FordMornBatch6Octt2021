package com.ford.relationships;

import java.util.Calendar;
import java.util.Date;

public class CalendarSample {

	//Date 
	//Calendar
	String[] month = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	String day[] = {"Sat","Sun","Mon","Tue","Wed","Thu","Fri"};
	public void useCalendarDate()
	{
		Date date = new Date();
		System.out.println("The Date is "+date.getDate());
		System.out.println("The date.getDay() "+date.getDay());
		System.out.println("The date.getMonth() "+date.getMonth());
		System.out.println("The date.getYear() "+date.getYear());
		System.out.println("The date.getHours() "+date.getHours());
		System.out.println("The date.getMinutes() "+date.getMinutes());
		System.out.println("The date.getSeconds() "+date.getSeconds());
		System.out.println("No Of Milliseconds lapsed since 1970 Jan 1 "+date.getTime());
		System.out.println("No Of Days lapsed since 1970 Jan 1 "+date.getTime()/(24 *60 * 60 * 1000));
		System.out.println("---------------CALENDAR CLASS ----------");
		Calendar cal = Calendar.getInstance();
		System.out.println("The Integer Const Representing  Day Of Month is "+Calendar.DAY_OF_MONTH);
		System.out.println("The  Integer Const Representing Day Of The Week "+Calendar.DAY_OF_WEEK);
		System.out.println("The  Integer Const Representing Day Of the Year is "+Calendar.DAY_OF_YEAR);
		System.out.println("The  Integer Const Representing Date is "+Calendar.DATE);
		System.out.println("The  Integer Const Representing Day Of The Week In Month "+Calendar.DAY_OF_WEEK_IN_MONTH);
		System.out.println("The  Integer Const Representing Year is "+Calendar.YEAR);
		System.out.println("The  Integer Const Representing Hour of Day is "+Calendar.HOUR_OF_DAY);
		System.out.println("The  Integer Const Representing Minute is "+Calendar.MINUTE);
		System.out.println("The  Integer Const Representing Second is "+Calendar.SECOND);
		System.out.println("------------------actual data --------------------");
		System.out.println("The Actual  Day Of Month is "+cal.get(Calendar.DAY_OF_MONTH));
		System.out.println("The Actual   Month is "+cal.get(Calendar.MONTH));
		System.out.println("The   Month is "+month[cal.get(Calendar.MONTH)]);
		System.out.println("The   Actual Day Of The Week "+cal.get(Calendar.DAY_OF_WEEK));
		System.out.println("The   Actual Day Of The Week "+day[cal.get(Calendar.DAY_OF_WEEK)]);
		System.out.println("The   Actual Day Of the Year is "+cal.get(Calendar.DAY_OF_YEAR));
		System.out.println("The   Actual Date is "+cal.get(Calendar.DATE));
		System.out.println("The   Actual Day Of The Week In Month "+cal.get(Calendar.DAY_OF_WEEK_IN_MONTH));
		System.out.println("The   Actual Year is "+cal.get(Calendar.YEAR));
		System.out.println("The   Actual Hour of Day is "+cal.get(Calendar.HOUR_OF_DAY));
		System.out.println("The   Actual Minute is "+cal.get(Calendar.MINUTE));
		System.out.println("The   Actual Second is "+cal.get(Calendar.SECOND));
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CalendarSample calendarSample = new CalendarSample();
		calendarSample.useCalendarDate();

	}

}
