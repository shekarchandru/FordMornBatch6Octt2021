package com.ford.relationships;

public class BaseClass {

	public void display()
	{
		System.out.println("Displaying Base Class...");
	}
}
