function addEvent(obj,evt,funct)
{
obj.addEventListener(evt,funct,false);
}