addEvent(window,'load',initialize);
function initialize()
{
var mySub = document.getElementById('sub1');
addEvent(mySub,'click',process);
}
function process()
{
var text1 = document.getElementById('t1');
var myText = document.getElementById('t1').value;
var myResultTxt = myText.initializeCap();
//alert(myResultTxt);
text1.value = myResultTxt;
}
String.prototype.initializeCap=function()
{
//world is beautiful -- 
var textArray = this.split(' '); // textArray[0] world [1] is [2] beautiful

for(var i=0;i<textArray.length;i++)
{
var preStr = textArray[i].charAt(0); // w ; i ;b
var postStr = textArray[i].substr(1) // orld ; s ; eautiful
var preStrU = preStr.toUpperCase();
var postStrL = postStr.toLowerCase();
var finalStr = preStrU+postStrL;
textArray[i] = finalStr;// World Is Beautiful
//alert(textArray[i]);
}

var newText = textArray.join(" ");
return newText;

}