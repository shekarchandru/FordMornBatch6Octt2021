addEvent(window,'load',initialize);
/* Variables representing the Controls */
var mySub;
/*var pnrNameTxt,pnrAddrTa;*/
var occuCombo;
var genderRad1,genderRad2,genderRad3;
/*var dtOfTravelDt;
var noOfTickNmbr;*/
var srcCityCombo;
var srcDestCombo;
var prefChk1,prefChk2,prefChk3,prefChk4;
var cojRad1,cojRad2,cojRad3,cojRad4;
/*var phoneTel;
var mailDet;*/

/* Variables to hold the Passenger details */
var pnrName,pnrAddr,pnrOccupation;
var gender,dtOfTravel,noOfTickets,srcCity,destCity,preferences;
var coj;
var pnrPhone,pnrMail;

function initialize()
{
mySub = document.getElementById('sub1');
occuCombo = document.getElementById('occup');
srcCityCombo = document.getElementById('src');
srcDestCombo =  document.getElementById('dest');

prefChk1 = document.getElementById('veg');
prefChk2 = document.getElementById('nveg');
prefChk3 = document.getElementById('smo');
prefChk4 = document.getElementById('nsmo');

genderRad1 = document.getElementById('gen1');
genderRad2 = document.getElementById('gen2');
genderRad3 = document.getElementById('gen3');

cojRad1 = document.getElementById('fcac');
cojRad2 = document.getElementById('fc');
cojRad3 = document.getElementById('sc');
cojRad4 = document.getElementById('scac');

addEvent(mySub,'click',process);
addEvent(occuCombo,'change',getOccupation);
addEvent(srcCityCombo,'change',getSrcDest);
addEvent(srcDestCombo ,'change',getSrcDest);
}
function process()
{
/*
var pnrName,pnrAddr,pnrOccupation;
var gender,dtOfTravel,noOfTickets,srcCity,destCity,preferences;
var coj;
var pnrPhone,pnrMail;
*/
alert("you submitted");
pnrName = document.getElementById('pnrName').value;
pnrAddr = document.getElementById('addr').value;
dtOfTravel = document.getElementById('dot').value;
noOfTickets = document.getElementById('nooftick').value;
pnrPhone = document.getElementById('tele').value;
pnrMail = document.getElementById('mail').value;
/* Consuming Gender */
	if(genderRad1.checked)
	{
		gender = "Male";
	}
	else if(genderRad2.checked)
	{
		gender = "FeMale";
	}
	else if(genderRad3.checked)
	{
		gender = "TransGender";
	}
	else
	{
		gender = "You Did Not Choose Gender";
	}

/* Consuming Class Of Journey */
	if(cojRad1.checked)
	{
		coj = "FirstClass AC";
	}
	else if(cojRad2.checked)
	{
		coj = "FirstClass";
	}
	else if(cojRad3.checked)
	{
		coj = "SecondClass AC";
	}
	else if(cojRad4.checked)
	{
		coj = "SecondClass";
	}
	else
	{
		coj = "You Did Not Choose Class";
	}
/* Consuming Preferences */
	if(prefChk1.checked && prefChk4.checked)
	{
		preferences = "You Preferred Veg & Non Smoking";
	}
	else if(prefChk2.checked && prefChk3.checked)
	{
		preferences = "You Preferred Non Veg & Smoking";
	}
	else
	{
		preferences = "You Did'nt Choose Preferences";
	}
}
function getOccupation()
{
	alert("You Selected Occupation");
}
function getSrcDest()
{
	alert("You Selected Source City or Dest City");

}