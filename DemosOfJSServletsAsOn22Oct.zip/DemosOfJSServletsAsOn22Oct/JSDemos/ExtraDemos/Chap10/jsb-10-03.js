var newWindow;
function makeNewWindow()
{
   newWindow = window.open("","","status,height=400,width=300");
}

function subWrite()
{
      // make new window if someone has closed it
      if (!newWindow || newWindow.closed)
      {
         makeNewWindow();
      }

   // bring subwindow to front
   newWindow.focus();
	var msg="hello"
   // assemble content for new window
   var newContent = '<!DOCTYPE html>';
   newContent += '<html>';
   newContent += '<head>';
   newContent += '<meta http-equiv="content-type" content="text/html;charset=utf-8">';
   newContent += '<title>A New Doc</title>';
   newContent += '<style type="text/css">';
   newContent += 'body { background-color: pink; }';
   newContent += '</style>';
   newContent += '</head>';
   newContent += '<body>';
   newContent += '<h1>This document <u><b><i>is brand</i> </b></u>new and We just<u> Created now.</u></h1>';
	newContent+= '<h1>'+msg+'</h1>';
   newContent += '</body>';
   newContent += '</html>';

   // write HTML to new window document
   newWindow.document.write(newContent);

   // close layout stream
   newWindow.document.close();
}


// add an event to an element
function addEvent(elem, evtType, func)
{
   if (elem.addEventListener)
   {
      elem.addEventListener(evtType, func, false);
   }
   else if (elem.attachEvent)
   {
      elem.attachEvent("on" + evtType, func);
   }
   else
   {
      elem["on" + evtType] = func;
   }
}

// apply behaviors when document has loaded
function initialize()
{
   // do this only if the browser can handle DOM methods
   if (document.getElementById)
   {
      // point to the button
      var oButtonRewrite = document.getElementById('writeSubwindow');

         // if it exists...
         if (oButtonRewrite)
         {
            // apply event handler
            addEvent(oButtonRewrite, 'click', subWrite);
         }
   }
}

// initialize when the page has loaded
addEvent(window, 'load', initialize);
//addEvent(window, 'load', makeNewWindow);