// initialize when the page has loaded
alert("In Js file");
addEvent(window, 'load', initialize);

function initialize()
{
   // do this only if the browser can handle DOM methods
   if (document.getElementById)
   {
      // point to critical elements
      var oButtonCreate = document.getElementById('create-window');
      var oButtonClose = document.getElementById('close-window');

         // if they all exist...
         if (oButtonCreate && oButtonClose)
         {
            // apply behaviors
            oButtonCreate.onclick = makeNewWindow;
            oButtonClose.onclick = closeNewWindow;
         }
   }
}

var newWindow;

function makeNewWindow()
{
	alert("inside making of window");
   newWindow = window.open("","","height=500,width=500");
}

function closeNewWindow()
{
   if (newWindow)
   {
      newWindow.close();
      newWindow = null;
   }
else
{
document.writeln("Window is Not Created");
}
}
