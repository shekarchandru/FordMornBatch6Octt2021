// initialize when the page has loaded
addEvent(window, 'load', initialize);

function initialize()
{
   // do this only if the browser can handle DOM methods
   if (document.getElementById)
   {
      // check for critical elements
      var oSource = document.getElementById('source');
      var oParameter1 = document.getElementById('parameter1');
      var oParameter2 = document.getElementById('parameter2');
      var oResult = document.getElementById('result');

         // if they all exist...
         if (oSource && oParameter1 && oParameter2 && oResult)
         {
            // apply behaviors
            addEvent(oParameter1, 'change', showResults);
            addEvent(oParameter2, 'change', showResults);
         }
         else
         {
            alert('Critical element not found');
         }
   }
}


// execute the method and display the result
function showResults()
{
   // get source text
   var oSource = document.getElementById('source');
   var sSource = oSource.firstChild.nodeValue;

   // get paramaters
   var oParameter1 = document.getElementById('parameter1');
   var iParameter1 = parseInt(oParameter1.options[oParameter1.selectedIndex].value);

   var oParameter2 = document.getElementById('parameter2');
   var iParameter2 = parseInt(oParameter2.options[oParameter2.selectedIndex].value);

   // generate result & display it
   var oResult = document.getElementById('result');

      if (!iParameter2)
      {
         oResult.value = sSource.substr(iParameter1);
      }
      else
      {
         oResult.value = sSource.substr(iParameter1, iParameter2);
      }
}
