// initialize when the page has loaded
addEvent(window, 'load', initialize);

var oList; 
var mytext;  // select list (global)
var oButton;
// apply behaviors when document has loaded
function initialize()
{
   // do this only if the browser can handle DOM methods
   if (document.getElementById)
   {
      // point to crucial elements
      oList = document.getElementById('urlList');
      oButton = document.getElementById('submit-button');
	mytext=document.getElementById('t1');
         // if they exist...
         if (oList && oButton)
         {
            // make the list dynamic
            addEvent(oList, 'change', goThere);

            // make the submit button disappear when JavaScript is running
            oButton.style.display = 'none';
         }
   }
}

// direct the browser to the selected URL
function goThere()
{
   location.href = oList.options[oList.selectedIndex].value;
}
