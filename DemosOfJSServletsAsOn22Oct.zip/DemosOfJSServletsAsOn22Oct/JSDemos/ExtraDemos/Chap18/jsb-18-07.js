// initialize when the page has loaded
addEvent(window, 'load', initialize);

function initialize()
{
   // do this only if the browser can handle DOM methods
   if (document.getElementById)
   {
      // point to critical elements
      oDelimiter = document.getElementById('delimiter');
      oOutput = document.getElementById('output');
      var oButtonShowAsIs = document.getElementById('showAsIs');
      var oButtonReverseIt = document.getElementById('reverseIt');
      var oReload = document.getElementById('reload');

         // if they all exist...
         if (oDelimiter && oOutput && oButtonShowAsIs && oButtonReverseIt)
         {
            // apply behaviors to buttons
            oButtonShowAsIs.onclick = showAsIs;
            oButtonReverseIt.onclick = reverseIt;
            oReload.onclick = function() { location.reload(); };

            // set global array
            solarSys = new Array("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune","Pluto","Karla");

         }      
   }
}

// show array as currently in memory
function showAsIs(evt)
{
   var delimiter = oDelimiter.value;
   oOutput.value = decodeURIComponent(solarSys.join(delimiter));
}

// reverse array order, then display as string
function reverseIt(evt)
{
   var delimiter = oDelimiter.value;
   solarSys.reverse();   // reverses original array
   oOutput.value = decodeURIComponent(solarSys.join(delimiter));
}
