// initialize when the page has loaded
addEvent(window, 'load', initialize);

function initialize()
{
   // do this only if the browser can handle DOM methods
   if (document.getElementById)
   {
      // point to critical elements
      oOutput = document.getElementById('output');
      var oButtonSortAsc = document.getElementById('sortAsc');
      var oButtonSortDesc = document.getElementById('sortDesc');
      var oButtonSortLastChar = document.getElementById('sortLastChar');
      var oButtonSortLength = document.getElementById('sortLength');
      var oReload = document.getElementById('reload');

         // if they all exist...
         if (oOutput && oButtonSortAsc && oButtonSortDesc && oButtonSortLastChar && oButtonSortLength && oReload)
         {
            // apply behaviors to buttons
            oButtonSortAsc.onclick = function() { sortIt(null) };
            oButtonSortDesc.onclick = function() { sortIt(compare1) };
            oButtonSortLastChar.onclick = function() { sortIt(compare2) };
            oButtonSortLength.onclick = function() { sortIt(compare3) };
            oReload.onclick = function() { location.reload(); };

            // set global array
            solarSys = new Array("Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune");
         }
   }
}

// comparison functions
function compare1(a,b)
{
   // reverse alphabetical order
   if (a > b)
      return -1;
   if (b > a)
      return 1;
   return 0;
}

function compare2(a,b)
{
   // last character of planet names
   var aComp = a.charAt(a.length - 1);
   var bComp = b.charAt(b.length - 1);
   if (aComp < bComp)
      return -1;
   if (aComp > bComp)
      return 1;
   return 0;
}

function compare3(a,b)
{
   // length of planet names
   return a.length - b.length;
}

// sort and display array
function sortIt(compFunc)
{
   if (compFunc == null)
   {
         solarSys.sort();
   }
   else
   {
         solarSys.sort(compFunc);
   }

   // display results in field
   var delimiter = ";";
   oOutput.value = decodeURIComponent(solarSys.join(delimiter));
}
