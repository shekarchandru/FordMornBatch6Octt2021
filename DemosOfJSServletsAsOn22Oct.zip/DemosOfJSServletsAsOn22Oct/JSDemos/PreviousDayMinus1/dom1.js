addEvent(window,'load',initialize);
var mySubButton;
function initialize()
{
mySubButton = document.getElementById('sub1');
addEvent(mySubButton,'click',process);
}
function process()
{
var myDate = new Date();
var strDate = myDate.toLocaleString();
var newNode = document.createTextNode(strDate);

var myPara = document.getElementById('para');
myPara.removeChild(myPara.firstChild);
myPara.appendChild(newNode);

}


