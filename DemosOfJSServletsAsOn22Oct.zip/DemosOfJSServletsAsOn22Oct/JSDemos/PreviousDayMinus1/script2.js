addEvent(window,'load',initialize);

var mySubmit;
var myRadio1,myRadio2,myRadio3;
var check1,check2,check3;

function initialize()
{
mySubmit = document.getElementById('sub1');

myRadio1 = document.getElementById('r1');
myRadio2 = document.getElementById('r2');
myRadio3 = document.getElementById('r3');

check1 = document.getElementById('ck1');
check2 = document.getElementById('ck2');
check3 = document.getElementById('ck3');

addEvent(mySubmit,'click',process1);

addEvent(myRadio1,'click',process2);
addEvent(myRadio2,'click',process2);
addEvent(myRadio3,'click',process2);

addEvent(check1,'click',process3);
addEvent(check2,'click',process3);
addEvent(check3,'click',process3);
}
function process1()
{
 alert("You Clicked on Submit Button");
}
function process2()
{
alert('checked');
	if(myRadio1.checked)
	{
		alert("You Selected Male as Gender....");
	}
	else if(myRadio2.checked)
	{
		alert("You Selected FeMale as Gender....");
	}
	else if(myRadio3.checked)
	{
		alert("You Selected TransGender....");
	}
	else
	{
		alert("You did not select Gender");
	}	
}
function process3()
{
	if(check1.checked)
	{
		alert("You have chosen Vegetarian as Preference...");
	}
	else if(check2.checked)
	{
		alert("You have chosen Non Vegetarian as Preference...");
	}
	else if(check3.checked)
	{
		alert("You have chosen Non Smoking as Preference...");
	}
	else
	{
		alert("You did not choose Preference...");
	}
}