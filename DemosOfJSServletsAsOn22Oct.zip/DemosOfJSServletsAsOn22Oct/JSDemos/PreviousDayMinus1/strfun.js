addEvent(window,'load',initialize);
var mySubmit;
var rad1,rad2,rad3;
function initialize()
{
mySubmit = document.getElementById('sub1');
addEvent(mySubmit,'click',processStrFns);
}
function processStrFns()
{
var textStr = document.getElementById('t1').value;
var resultTxt = document.getElementById('t4');
var resultStr;
var arg1 = document.getElementById('t2').value;
var arg2 = document.getElementById('t3').value;
rad1 = document.getElementById('r1');
rad2 = document.getElementById('r2');
rad3 = document.getElementById('r3');

if(rad1.checked)
{
	resultStr = textStr.substr(arg1,arg2);
}
else if(rad2.checked)
{
	resultStr = textStr.substring(arg1,arg2);
}
else if(rad3.checked)
{
	resultStr = textStr.slice(arg1,arg2);
}
else
{
	resultStr = "You did not Choose...";
}
resultTxt.value = resultStr;

}