

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalciServlet
 */
@WebServlet("/CalciServlet")
public class CalciServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CalciServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
		int number1,number2;
		double result = 0.0;
		String option;
		String resultStr;
		number1 = Integer.parseInt(request.getParameter("num1"));
		number2 = Integer.parseInt(request.getParameter("num2"));
		
		option = request.getParameter("calci");
		
		if(option.equals("add"))
		{
			result = number1 + number2;
		}
		else if(option.equals("sub"))
		{
			result = number1 - number2;
		}
		else if(option.equals("mul"))
		{
			result = number1 * number2;
		}
		else if(option.equals("div"))
		{
			result = number1 / number2;
		}
		else
		{
			resultStr = "You did'nt choose Operation..";
		}
		pw.println("<html><body bgcolor='yellow'>");
		pw.println("The Operation you have chosen is "+option);
		pw.println("The Result is :"+result);
		pw.println("<a href='Calculator.html'>Go Back To Calci Page..</a>");
		pw.println("</body></html>");
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
